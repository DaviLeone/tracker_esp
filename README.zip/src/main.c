#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/rtc.h>
#include <zephyr/sys/printk.h>

#define LED_PIN 2

static const struct device *gpio_dev = DEVICE_DT_GET(DT_NODELABEL(gpio0));
static const struct device *rtc_dev = DEVICE_DT_GET(DT_NODELABEL(ds3231_rtc));

int main(void)
{
	struct rtc_time tm;
	int last_sec = -1;

	if (!device_is_ready(gpio_dev) || !device_is_ready(rtc_dev)) {
		printk("Erro: GPIO ou RTC DS3231 nao esta pronto.\n");
		return 0;
	}

	gpio_pin_configure(gpio_dev, LED_PIN, GPIO_OUTPUT_INACTIVE);

	/* Se o RTC ainda nao tiver horario valido (primeira ligacao), ajusta a hora inicial */
	if (rtc_get_time(rtc_dev, &tm) < 0) {
		struct rtc_time init_tm = {
			.tm_year = 2026 - 1900,
			.tm_mon  = 11 - 1,
			.tm_mday = 13,
			.tm_hour = 13,
			.tm_min  = 40,
			.tm_sec  = 0,
		};
		rtc_set_time(rtc_dev, &init_tm);
		printk("Horario inicial gravado no DS3231.\n");
	}

	while (1) {
		if (rtc_get_time(rtc_dev, &tm) == 0) {
			/* Imprime o horario no serial a cada segundo do RTC */
			if (tm.tm_sec != last_sec) {
				last_sec = tm.tm_sec;
				printk("RTC: %02d:%02d:%02d\n",
				       tm.tm_hour, tm.tm_min, tm.tm_sec);
			}

			/* Durante os primeiros 10 segundos de cada minuto (00 a 09), pisca o LED */
			if (tm.tm_sec < 10) {
				gpio_pin_toggle(gpio_dev, LED_PIN);
			} else {
				gpio_pin_set(gpio_dev, LED_PIN, 0);
			}
		}

		k_msleep(250);
	}

	return 0;
}